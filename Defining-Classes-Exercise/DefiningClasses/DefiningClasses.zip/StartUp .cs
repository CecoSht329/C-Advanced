﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            Person person = new Person();

            person.Name = "Pesho";
            person.Age = 20;
        }
    }
}
